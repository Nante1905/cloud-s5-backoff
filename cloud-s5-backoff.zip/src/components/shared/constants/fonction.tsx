function replaceSubstring(mainString, ch1, ch2) {
    // Utilisez la méthode replace pour effectuer le remplacement
    const resultString = mainString.replace(ch1, ch2);
    return resultString;
  }
  


  export { replaceSubstring };