export interface Marque {
    id?: number;
    nom: string;
    logo:string;
  }
  