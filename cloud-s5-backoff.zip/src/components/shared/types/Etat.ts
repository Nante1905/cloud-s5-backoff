export interface Etat {
    id?: number;
    nom: string;
    valeur : number;
  }
  