export interface Energie {
    id?: number;
    nom: string;
  }
  