export interface Couleur {
  id?: number;
  nom: string;
  hexa: string;
}
