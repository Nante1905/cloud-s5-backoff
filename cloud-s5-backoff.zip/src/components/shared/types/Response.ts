/* eslint-disable @typescript-eslint/no-explicit-any */
export interface ApiResponse {
    message: string,
    err: string,
    data: any,
    ok: boolean
}