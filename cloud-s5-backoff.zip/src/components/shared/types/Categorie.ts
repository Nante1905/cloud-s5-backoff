export interface Categorie {
    id?: number;
    nom: string;
  }
  