import React from "react";
import BeneficeParMarque from "../benefice-par-marque/benefice-par-marque.component";

const StatsBenefice = () => {
  return (
    <div>
      <BeneficeParMarque />
    </div>
  );
};

export default StatsBenefice;
