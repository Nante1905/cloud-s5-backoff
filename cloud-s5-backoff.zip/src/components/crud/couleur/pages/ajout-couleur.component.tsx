import React from "react";
import CouleurFormComponent from "../components/couleur-form.components";

const AjoutCouleurComponent = () => {
    document.title = "Couleurs";
    return <CouleurFormComponent/>;
};

export default AjoutCouleurComponent;
