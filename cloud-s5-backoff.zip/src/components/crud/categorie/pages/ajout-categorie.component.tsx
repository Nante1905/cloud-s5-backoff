import CategorieFormComponent from "../components/categorie-form.components";

const AjoutCategorieComponent = () => {
  document.title = "Ajout d'une catégorie";
  return <CategorieFormComponent />;
};

export default AjoutCategorieComponent;
