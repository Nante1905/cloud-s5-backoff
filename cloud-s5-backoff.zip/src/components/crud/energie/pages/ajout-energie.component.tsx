import React from "react";
import EnergieFormComponent from "../components/energie-form.components";

const AjoutEnergieComponent = () => {
    document.title = "Energies";
    return <EnergieFormComponent/>;
};

export default AjoutEnergieComponent;
