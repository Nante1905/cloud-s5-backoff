import React from "react";
import MarqueFormComponent from "../components/marque-form.components";

const AjoutMarqueComponent = () => {
    document.title = "Marques";
    return <MarqueFormComponent/>;
};

export default AjoutMarqueComponent;
