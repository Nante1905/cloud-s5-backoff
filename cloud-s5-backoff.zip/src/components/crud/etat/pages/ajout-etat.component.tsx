import EtatFormComponent from "../components/etat-form.components";

const AjoutEtatComponent = () => {
  document.title = "Etat";
  return <EtatFormComponent />;
};

export default AjoutEtatComponent;
