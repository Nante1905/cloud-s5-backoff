import React from "react";
import InscriptionFormComponent from "./inscription-form.components";

const InscriptionRoot = () => {
    document.title = "inscription";
    return  <>
        <InscriptionFormComponent />
     </>;
};

export default InscriptionRoot;
