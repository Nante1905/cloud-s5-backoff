import { Alert, Button, Snackbar, TextField } from "@mui/material";
import { FormEvent, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "../../../assets/fontawesome-5/css/all.min.css";
import { Utilisateur } from "../../shared/types/Utilisateur";
import AppLoaderComponent from "../../shared/loader/app-loader.component";
import Title from "../../shared/title/title.component";
import "./inscription-form.component.scss";
interface UtilisatuerFormProps {
    entity?: Utilisateur;
}


const InscriptionFormComponent = ( props: UtilisatuerFormProps  ) => {
    const [state, setState] = useState<UtilisateurFormState>(initialState);
    useEffect(() => {
        if (props.entity) {
          setState((state) => ({
            ...state,
            form: {
              ...(props.entity as Utilisateur),
            },
          }));
        }
      }, []);

const utilisateur = props.entity;

return (
    <div className="form-temp inscription-form">
          <div className="background-clip-path">
        
        </div>
      <div className="container-form">
        <div className="title-form">
          <Title>{"Inscription"}</Title>
        </div>
        {state.error && (
          <div className="success-error-form" style={{ color: "red" }}>
            {state.error}
          </div>
        )}
        {state.success && (
          <div className="success-error-form" style={{ color: "green" }}>
            {state.success}
          </div>
        )}
        <form>
          <div className="form">
            <TextField
              label="Nom"
              onChange={(event) =>
                setState((state) => ({
                  ...state,
                  form: {
                    ...state.form,
                    nom: event.target.value as string,
                  },
                }))
              }
              value={state.form.nom}
            />
            <TextField
              label="prénom"
              onChange={(event) =>
                setState((state) => ({
                  ...state,
                  form: {
                    ...state.form,
                    prenom: event.target.value as string,
                  },
                }))
              }
              value={state.form.prenom}
            />
            <TextField
              label="Email"
              type="email"
              onChange={(event) =>
                setState((state) => ({
                  ...state,
                  form: {
                    ...state.form,
                    email: event.target.value as string,
                  },
                }))
              }
              value={state.form.email}
            />
            <TextField
              label="adresse"
              onChange={(event) =>
                setState((state) => ({
                  ...state,
                  form: {
                    ...state.form,
                    adresse: event.target.value as string,
                  },
                }))
              }
              value={state.form.adresse}
            />
            <AppLoaderComponent loading={state.submitLoading}>
              <Button variant="contained" type="submit">
                <>{"S'inscrire"}</>
              </Button>
            </AppLoaderComponent>
          </div>
        </form>
      </div>

      <Snackbar open={state.error !== null}>
        <Alert severity="error">{state.error as string}</Alert>
      </Snackbar>
      <Snackbar open={state.success !== null}>
        <Alert severity="success">{state.success as string}</Alert>
      </Snackbar>
    </div>
  );
}

interface UtilisateurFormState {
    form: Utilisateur;
    success: string | null;
    error: string | null;
    submitLoading: boolean;
  }

  const initialState: UtilisateurFormState = {
    form: {
      nom: "",
      prenom: "",
      email:"",
      adresse: "",
      dateInscription : ""
    },
    success: null,
    error: null,
    submitLoading: false,
  };

export default InscriptionFormComponent;